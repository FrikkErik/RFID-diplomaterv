package rfid.app.backend.dto;

public enum ResultType {
    ERROR, SUCCESS, FINISHED
}
