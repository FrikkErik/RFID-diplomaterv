export default interface ColorType {
    id: number;
    name: string;
    hue: number;
    brightness: number;
    saturation: number;
}
