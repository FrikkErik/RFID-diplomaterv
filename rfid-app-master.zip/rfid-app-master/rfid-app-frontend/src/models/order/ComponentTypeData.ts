import ComponentType from './ComponentType';

export default interface ComponentTypeData {
    componentType: ComponentType;
    colorId: number;
}
