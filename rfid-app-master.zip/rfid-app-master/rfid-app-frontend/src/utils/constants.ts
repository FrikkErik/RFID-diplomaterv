export const timeout = {
    success: 1000,
    finished: 3000,
    error: 2000
}
